// @flow

import { mount } from 'redom';
// import { historyCardDemo } from './demo/historyCardDemo';
// import { bioCardDemo } from './demo/bioCardDemo';
import { calendarCardDemo } from './demo/calendarCardDemo';

mount(document.body, calendarCardDemo);
